module.exports.run = (client, message, args) => {
    if (message.author.id == '232191205700534275') message.channel.send(`Thank you, Master.`);
    else message.channel.send(`Thank you.`);
}